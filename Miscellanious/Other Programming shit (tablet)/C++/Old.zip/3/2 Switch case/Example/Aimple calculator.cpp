#include <iostream>
using namespace std;

int main(){
    int n1, n2;
    cout << "Enter 2 numbers\n";
    cin >> n1 >> n1;
    
    char op;
    cout << "Ener an operation\n";
//jump:
    cin >> op;
    
    int res;
    switch(op)
    {
        case '+':
            res = n1 + n2;
            cout << res << endl;
          break;
          
        case '-':
            res = n1 - n2;
            cout << res << endl;
          break;
        
        case '*':
            res = n1 * n2;
            cout << res << endl;
          break;
        
        case '/':
            res = n1 / n2;
            cout << res << endl;
          break;
        
        case '%':
            res = n1 % n2;
            cout << res << endl;
          break;
        
        default:
            cout << "Enter a vaild operation\n";
       //     goto jump;
          break;
    }
    
    
    return 0;
}