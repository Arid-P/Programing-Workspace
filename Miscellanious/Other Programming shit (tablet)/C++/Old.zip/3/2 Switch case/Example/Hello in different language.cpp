#include <iostream>
using namespace std;

int main(){
    char g;
    cin >> g;
    
    /*{if(g == 'a'){
        cout << "Hello\n";
    }
    else if(g == 'b'){
        cout << "Namaste\n";
    }
    else if(g == 'c'){
        cout << "Hola\n";
    }
    else if(g == 'd'){
        cout << "Salut\n";
    }
    else if(g == 'e'){
        cout << "Ciao\n";
    }
    else{
        cout << "I am still learning more \n";
    }
    this or use switch case}*/
    
    switch(g)
    {
        case 'a':
            cout << "Hello\n";
          break;
        case 'b':
            cout << "Namaste\n";
          break;
        case 'c':
            cout << "Hola\n";
          break;
        case 'd':
            cout << "Salut\n";
          break;
        case 'e':
            cout << "Ciao\n";
          break;
        default:
            cout << "I am still learning more\n";
          break;
    }
    
    
    return 0;
}