#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;
    
    if(n<10){
      cout << "It is less than 10\n";
    }
    else if(n>10){
      cout << "It is more than 10\n";
    }
    else{
      cout << "It is equal to 10\n";
    }
    
    return 0;
}