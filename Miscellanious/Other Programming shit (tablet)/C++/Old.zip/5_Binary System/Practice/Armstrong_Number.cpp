#include <iostream>
using namespace std;

int main(){
    int n, l, u=0;
    cin >> n;

    while(n>0){
        l=n%10;
        u=u*10+l;
        n/=10;
    }

    cout << u << endl;
    return 0;
}