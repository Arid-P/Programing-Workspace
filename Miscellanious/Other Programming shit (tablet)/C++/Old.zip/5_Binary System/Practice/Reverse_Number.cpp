#include <iostream>
#include <math.h>
using namespace std;

int main(){
    int n, n2, l, s=0;
    cin >> n;
    n2 = n;
    
    while(n2>0){
        l=n2%10;
        s=s+pow(l,3);
        n/=10;
    }

    if(s==n){
       cout << "armstrong number\n" ;
        return 0;
    }

    cout << "not armstrong number\n";
    return 0;
}