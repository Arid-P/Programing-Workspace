#include <iostream>
using namespace std;

int main(){
    int r, z=3;
    cin >> r;

    for(int i=1; i<=r; i++){
        int j;
        for(j=1; j<=(r-i); j++)
            cout << "  ";
        cout << "*";

        if(!(i==1)){
            for(j=1; j<=z; j++)
                cout << " ";
            cout << "*";
            z+=4;
        }
        cout << endl;
    }
    
    
    if(r%2==0){
        for(int i=r; i>=1; i--){
            int j;
            for(j=1; j<=(r-i); j++)
                cout << "  ";
            cout << "*";
            if(!(i == 1)){
            	 z -= 4;
            	 for(j=1; j<=z; j++)
                     cout << " ";
                cout << "*";
            }
            cout << endl;
        }
    }
    else{
        z -= 4;
        for(int i=(r-1); i>=1; i--){
        int j;
        for(j=1; j<=(r-i); j++)
            cout << "  ";
        cout << "*";
        
        if(!(i == 1)){
            z -= 4;
            for(j=1; j<=z; j++){
                cout << " ";
            }   
            cout << "*";
        }
        cout << endl;
       }
    }

    return 0;
}