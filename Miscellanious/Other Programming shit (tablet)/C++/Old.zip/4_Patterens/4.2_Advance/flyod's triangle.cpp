#include <iostream>
using namespace std;

int main(){
  int row, value=1;
  cin >> row;
  cout << endl;
  
  for(int i=1; i<=row; i++){
    for(int j=1; j<=i; j++){
      cout << value << " ";
      value++;
    }
    cout << endl;
  }
  
  return 0;
}