#include <iostream>
using namespace std;

int main(){
    int r, s;
    cin >> r;
    s = 2*r - 2;
    
    for(int i=1; i<=r; i++){
        int j;
        for(j=1; j<=i; j++)
            if(j==1 || j==i){
                cout << "*";
            }
            else{
                cout << " ";
            }
        
        for(j=1; j<=s; j++)
            cout << " ";
        s -= 2;
        
        for(j=1; j<=i; j++)
            if(j==1 || j==i){
                cout << "*";
            }
            else{
                cout << " ";
            }
        
        cout << endl;
    }

    s += 2;
    for(int i=r; i>=1; i--){
        int j;
        for(j=1; j<=i; j++)
            if(j==1 || j==i){
                cout << "*";
            }
            else{
                cout << " ";
            }
        
        for(j=1; j<=s; j++)
            cout << " ";
        s += 2;
        
        for(j=1; j<=i; j++)
            if(j==1 || j==i){
                cout << "*";
            }
            else{
                cout << " ";
            }
        
        cout << endl;
    }
    

    return 0;
}