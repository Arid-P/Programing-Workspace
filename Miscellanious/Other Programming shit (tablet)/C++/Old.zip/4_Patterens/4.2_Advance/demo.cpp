#include <iostream>
using namespace std;

int main()
{
    int r, c=0;
    cin >> r;
    for(int i=1; i<=r; i++)
        c+=i;

    int darr[r][c];

    for(int i=0; i<2; i++){
        for(int j=0; j<2; j++){
            darr[i][j] = 1;
        }
    }

    if(r>2){
        for(int i=3; i<=r; i++){
            int p1 = 0, p2 = 1, j;
            int arr[i-2];
            for(j=1; j<=(i-2); j++){
                arr[j] = darr[i-2][p1] + darr[i-2][p2];
                p1++;
                p2++;
            }
            darr[i-1][0] = 1;
            darr[i-1][i-1] = 1;
            for(j=1; j<=(i-2); j++){
                darr[i-1][j] = arr[j];
            }
        }
    }

    for(int i=1; i<=r; i++){
        int j;
        for(j=1; j<=(r-i); j++)
            cout << " ";
        for(int j=1; j<=i; j++)
            cout << darr[i-1][j-1] << " ";
        cout << endl;
    }

    main();
    return 0;
}