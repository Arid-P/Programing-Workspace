#include <iostream>
using namespace std;

int main(){
    int r, z=1;
    cin >> r;

    for(int i=0; i<r; i++){
        int j;
        for(j=1; j<=(r-i); j++)
            cout << "*";

        if(!(i==0)){
            for(j=1; j<=z; j++)
                cout << " ";
            cout << "*";
            z+=2;
        }
        for(j=(r-i-1); j>=1; j--)
            cout << "*";
        cout << endl;
    }
    
    
    if(r%2==0){
        z-=2;
        for(int i=(r-1); i>=0; i--){
            int j;
        	for(j=1; j<=(r-i); j++)
           	 cout << "*";

        	if(!(i==0)){
           	 for(j=1; j<=z; j++)
               	 cout << " ";
            	cout << "*";
            	z-=2;
        	}
        	for(j=(r-i-1); j>=1; j--)
           	 cout << "*";
        	cout << endl;
        }
    }
    else{ // odd
        z -= 4;
        for(int i=(r-2); i>=0; i--){
            int j;
        	for(j=1; j<=(r-i); j++)
           	 cout << "*";

        	if(!(i==0)){
           	 for(j=1; j<=z; j++)
               	 cout << " ";
            	cout << "*";
            	z-=2;
        	}
        	for(j=(r-i-1); j>=1; j--)
           	 cout << "*";
        	cout << endl;
        }
    }

    return 0;
}