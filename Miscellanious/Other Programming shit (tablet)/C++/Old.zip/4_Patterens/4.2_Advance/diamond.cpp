#include <iostream>
using namespace std;

int main(){
  int r, j, i;
  cin >> r;
  
  for(i=1; i<=r; i++){
    for(j=1; j<=(r-i); j++)
      cout << "  ";
    
    for(j=1; j<=i; j++)
      cout << "*";
    
    for(j=2; j<=i; j++)
      cout << "*";
    cout << endl;
  }
  
  for(i=r; i>=1; i--){
    for(j=1; j<=(r-i); j++)
      cout << "  ";
    
    for(j=1; j<=i; j++)
      cout << "*";
    
    for(j=2; j<=i; j++)
      cout << "*";
    cout << endl;
  }
  
  return 0;
}