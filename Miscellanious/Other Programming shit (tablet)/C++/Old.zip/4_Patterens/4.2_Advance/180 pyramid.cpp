#include <iostream>
using namespace std;

int main(){
  int r, i, j, y;
//  cin >> r;
r=5;
  
  y = r+1; // 6
  //for(i=1; i<=r; i++){
//    for(j=1; j<=(r-i); j++)
//      cout << "  ";
//    for(j=1; j<=r; j++){
//      if((j+i) == y){
//        cout << "*";
//        break;
//      }
//    }
//    cout << endl;
//  }
  
  for(i=(r+1); i>1; i--){
    for(j=(r-i); j<=(r-i+1); j++)
      cout << " k";
    for(j=1; j<=r; j++){
      if((j+i) == y){
        cout << "*";
      }
    }
    cout << endl;
  }
  
  return 0;
}