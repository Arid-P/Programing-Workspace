#include <iostream>
using namespace std;

int main(){
  int row;
  cin >> row;
  cout << endl;
  
  for(int i=1; i<=row; i++){
    for(int j=1; j<=i; j++){
      if(i%2==0){
        if(j%2==0){
          cout << "1 ";
          continue;
        }
        else{
          cout << "0 ";
        }
        continue;
      }
      else{
        if(j%2==0){
          cout << "0 ";
          continue;
        }
        else{
          cout << "1 ";
        }
      }
    }
    cout << endl;
  }
  
  return 0;
}