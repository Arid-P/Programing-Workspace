#include <iostream>
using namespace std;

int main(){
  int col;
  cin >> col;
  
  for(int i=(col-1); i>=0; i--){
     for(int j=1; j<=i; j++)
       cout << "  ";
    
    for(int j=1; j<=(col-i); j++)
      cout << "*";
    5
    cout << endl;
  }
  
  return 0;
}