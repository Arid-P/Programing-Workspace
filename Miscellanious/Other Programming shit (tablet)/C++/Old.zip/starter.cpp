#include <iostream>
using namespace std;

int main()
{
    int row, col;
    cout << "Enter the row number" << endl;
    cin >> row;
    cout << "Enter the column number" << endl;
    cin >> col;

    int arr[row][col];
    for(int i=0; i<row; i++)
	{
        for(int j=0; j<col; j++)
        {
            cin >> arr[i][j];
        }
    }


    cout << "\nThe Matrix is \n";
	for(int i=0; i<row; i++)
	{
	    for(int j=0; j<col; j++)
	    {
	        cout << arr[i][j] << " ";
	    }
	    cout << endl;
	}
	
	
	return 0;
}





#include <iostream>
using namespace std;

int main()
{
  int size;
    cout << "Enter the size of the array" << endl;
    cin >> size;
    
    int arr[size];
    
    cout << "Enter the value" << endl;
    for(int i=0; i<size; i++)
    {
      cin >> arr[i];
    }
    
    
    return 0;
}


#include <iostream>
using namespace std;

int main()
{
    
    
    return 0;
}

Programing: dict = {
    "Backup" : [Acode.backup],
    "C++" : {
        "(Old)" : 
    },

