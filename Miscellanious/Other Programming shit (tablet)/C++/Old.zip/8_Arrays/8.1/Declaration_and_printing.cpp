#include <iostream>
using namespace std;

int main() {
    int s;
    cin >> s;

    int arr[s];
    for(int i=0; i<s; i++)
    	cin >> arr[i]; //input 

    for(int i=0; i<s; i++)
        cout << arr[i] << " "; //output

    return 0;
}