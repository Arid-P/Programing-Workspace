#include <iostream>
using namespace std;

int main() {
    int s;
    cin >> s;

    int arr[s];
    for(int i=0; i<s; i++)
    	cin >> arr[i];
    
    int min = arr[0];
    int max = arr[0];

    for(int i=1; i<s; i++)
        if(arr[i] > max)
           max = arr[i]; 
        else if(arr[i] < min)
            min = arr[i];

    cout << max << endl;
    cout << min << endl;
    
    return 0;
}