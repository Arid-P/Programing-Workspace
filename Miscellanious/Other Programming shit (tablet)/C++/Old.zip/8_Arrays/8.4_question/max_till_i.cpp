#include <iostream>
using namespace std; 
int main() {
 int s;
 cin >> s;
 int arr[s];
 for(int i=0; i<s; i++)
    cin >> arr[i];
    int 
    mx = arr[0];
    for(int i=1; i<s; i++){
        mx = max(mx, arr[i]);
        cout << mx << endl;
    }
    
    return 0;
}
