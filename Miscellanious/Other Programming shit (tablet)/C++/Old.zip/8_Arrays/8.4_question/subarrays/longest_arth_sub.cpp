#include <iostream>
using namespace std;

int longest_arthimatic_array (int a[], int n){
    int ans = 2;
    // current common diff
    int pd = a[1] - a[0];
    // starting point
    int j = 2; 
    // current max length
    int curr = 2; 
    
    while(j < n){
        if(pd == a[j] - a[j-1]){
            curr++;
            ans = max(ans, curr);
        }
        else{
            pd = a[j] - a[j-1];
            curr = 2;
        }
        j++;
    }
    
    return ans;
}

int main() {
    int t;
    cin >> t;
    cout << endl;

    for(int i=1; i<=t; i++){
        int n;
        cin >> n;

        int a[n];
        for(int j=0; j<n; j++)
            cin >> a[j];

        cout << "#" << i << " ";
        cout << longest_arthimatic_array(a, n);
        cout << endl << endl;
    }

    return 0;
}
        
