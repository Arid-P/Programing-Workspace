#include <iostream>
using namespace std;
int main(int argc, char *argv[]) {
 int s = 3;
 cin >> s;

 int arr[s];
 for (int i = 0; i < s; i++)
        cin >> arr[i];

 int i, j;
 for (i = 0; i < s; i++){
        int curr = 0;
        for (j = i; j < s; j++){
            curr += arr[j];
            cout << curr << endl;
        }
        cout << endl;
    }
    
    return 0;
}
