#include <iostream>
using namespace std;

int no_of_record_breaking_days (int arr[], int n){
  int maxNo = arr[0];
  // no_of_record_breaking_days
  int nrbd = 0;

   for (int i = 1; i < n-1; i++) 
    if (maxNo < arr[i] && arr[i] > arr[i+1]){
      nrbd++;
      maxNo = arr[i];
    }
   

  if (arr[0] > arr[1] || maxNo < arr[n-1]) {
    nrbd++;
  }


  return nrbd;
}

int main() {
  cout << "start" << endl;
  int t;
  cin >> t;
  cout << endl;

  for(int i=1; i<=t; i++){
    int n;
    cin >> n;

    int a[n];
    for(int j=0; j<n; j++)
      cin >> a[j];

    cout << "#" << i << " ";
    cout << no_of_record_breaking_days(a, n);
    cout << endl << endl;
  }

    return 0;
}
        
