#include <iostream>
using namespace std;

void sort(int arr[], int s){

    for(int i=s-1; i>1; i--)
        for(int j=0; j<i; j++)
            if(arr[j] > arr[j+1]){
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
    
}

int main() {
    int s;
    cin >> s;

    int arr[s];
    for(int i=0; i<s; i++)
    	cin >> arr[i];

    sort(arr, s);
    for(int i=0; i<s; i++)
        cout << arr[i] << " ";
    
    return 0;
}