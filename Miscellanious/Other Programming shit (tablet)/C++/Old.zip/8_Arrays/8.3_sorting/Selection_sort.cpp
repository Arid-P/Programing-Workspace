#include <iostream>
#include <climits>
using namespace std;

void sort(int arr[], int n) {
  
  for(int i=0; i<n; i++){
    int in, minNo = INT_MAX;
    for(int j=i; j<n; j++)
      if(arr[j] < minNo){
          minNo = arr[j];  
          in = j;
      }
    int temp = arr[i];
    arr[i] = minNo;
    arr[in] = temp;
  }
}

int main(){
  int size;
    std::cout << "Enter the size of the array" << endl;
    std::cin >> size;
    
    int arr[size];
    
    std::cout << "Enter the value" << endl;
    for(int i=0; i<size; i++)
      std::cin >> arr[i];
    
    sort(arr, size);
    for(int i=0; i<size; i++)
      std::cout << arr[i] << " ";
    
    return 0;
}
