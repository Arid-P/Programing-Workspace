#include <iostream>
using namespace std;

void sort(int arr[], int s){

    for(int i=1; i<s; i++){
        int in=i, j;
        
        for(j=0; j<i; j++)
            if(arr[i] < arr[j]){
                in = j;
                break;
            }
        
        for(j=in; j<i; j++){
            int temp = arr[j];
            arr[j] = arr[i];
            arr[i] = temp;
        }
    }
    
}

int main() {
    int s;
    cin >> s;

    int arr[s];
    for(int i=0; i<s; i++)
    	cin >> arr[i];

    sort(arr, s);
    for(int i=0; i<s; i++)
        cout << arr[i] << " ";
    cout << endl;
    
    return 0;
}