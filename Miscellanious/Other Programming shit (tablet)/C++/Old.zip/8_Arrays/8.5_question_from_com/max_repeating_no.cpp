#include <iostream>
using namespace std;

int max_repeating_no (int arr[], int n) {
  // max no of repeatation
  int maxR = 0;
  // current no of repeatation
  int currR;

  int ans = 0;
  for (int i = 0; i < n; i++) {

    currR = 0;
    for(int j = i+1; j < n; j++) 
      if (arr[i] == arr[j]) { 
        currR++;
      }
    
    
    if (currR > maxR) {
      maxR = currR;
      ans = i;
    }
  }

  return ans;
}

int main (int argc, char *argv[]) {
  cout << "start" << endl;

  int n = 6;
  cin >> n;

  int arr[] = {1, 5, 4, 3, 6, 5};

  for(int i=0; i<n; i++)
    cin >> arr[i];

  cout << max_repeating_no(arr, n) << endl;

  return 0;
}
