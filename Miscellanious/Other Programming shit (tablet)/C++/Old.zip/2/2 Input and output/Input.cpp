#include <iostream>
using namespace std;

int main(){
    int amount1, amount2;
    cin >> amount1; //moms money
    cin >> amount2; // fathers money
    
    int sum = amount1 + amount2; // sum of values
    
    cout << "sum\n"; 
    cout << sum;
    
    return 0;
}