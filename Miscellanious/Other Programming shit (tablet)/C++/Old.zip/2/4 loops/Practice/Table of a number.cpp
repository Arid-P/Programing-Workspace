#include <iostream>
using namespace std;

int main()
{#include <iostream>
using namespace std;

int main(){
    int n;
    cout << "Enter a number\n";
    cin >> n;
    
    for(int i=1; i<=10; i++)
        cout << n << " * " << i << " = " << (n*i) << endl;
    
    return 0;
}
    
    
    return 0;
}