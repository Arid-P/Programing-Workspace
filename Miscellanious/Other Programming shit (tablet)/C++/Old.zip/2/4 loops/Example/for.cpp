#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;
    
    int sum = 0;
    for(int i=0; i<=n; i++){
      sum += i; // x += y --> x = x + y
    }
    cout << sum << endl;
    
    return 0;
}