#include <iostream>
using namespace std;

int main(){
  int a;//declaration
  a=12;//insitialisation
  cout << "size of int is " << sizeof(a) << endl;
  
  float b;
  cout << "size of float is " << sizeof(b) << endl;
  
  char c;
  cout << "size of int is " << sizeof(c) << endl;
  
  bool d;
  cout << "size of int is " << sizeof(d) << endl;
  
  long int li;
  cout << "size of int is " << sizeof(li) << endl;
  
  short int si;
  cout << "size of int is " << sizeof(si) << endl;
  
  return 0;
}