#include <iostream>
using namespace std;

int main(){
    int saving;
    cin >> savings;
    
    if(saving>5000){
        cout << "Neha\n";
    }
    else{
        cout << "Rashmi\n";
    }
    
    return 0;
}