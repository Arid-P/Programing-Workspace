#include <iostream>
using namespace std;

int main(){
    int saving;
    cin >> saving;
    
    if(saving>5000){
        if(saving>10000){
            cout << "roadtrip with Neha\n";
        }
        else{
            cout << "shopping with Neha\n";
        }
    }
    else{
        cout << "Rashmi\n";
    }
    
    return 0;
}