#include <iostream>
using namespace std;

int main(){
    float a, b, c;
    cout << "Enter first side length\n";
    cin >> a;
    
    cout << "Enter second side length\n";
    cin >> b;
    
    cout << "Enter third side length\n";
    cin >> c;
    
    if((a==b)&&(a==c)){
        cout << "It is an equilateral triangle\n";
    }
    else if((a==b) || (a==c) || (b==c)){
        cout << "It is an isoscles triangle\n";
    }
    else{
        cout << "It is an scalene triangle\n";
    }
    
    return 0;
}