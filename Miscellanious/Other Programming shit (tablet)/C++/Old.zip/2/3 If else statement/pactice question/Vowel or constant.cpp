#include <iostream>
using namespace std;

int main(){
    char a;
    cout << "Enter character\n";
    cin >> a;
    
    bool isLowerCase, isUpperCase;
    isLowerCase = (a=='a' || a=='e' || a=='o' || a=='i' || a=='u');
    isUpperCase = (a=='A' || a=='E' || a=='O' || a=='I' || a=='U');
    
    if(isLowerCase || isUpperCase){
        cout << a << " is a vowel\n";
    }
    else{
        cout << a << " is a constant\n";
    }
    
    return 0;
}