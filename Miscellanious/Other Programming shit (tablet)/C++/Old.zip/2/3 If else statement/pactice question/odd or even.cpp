#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;
    
    if(n%2==0){
      cout << n << " is even\n";
    }
    else{
      cout << n << " id odd\n";
    }
    
    return 0;
}