#include <iostream>
using namespace std;

bool isprime(int ip)
{
    for(int i=2; i<=sqrt(ip); i++){
        if(ip%i == 0){
            return false;
        }
    }
    return true;
}

int main(int argc, char *argv[])
{
	int a, b;
	cin>>a>>b;
	
	for(int i=a; i<=b; i++){
	    if(isprime(i)){
	        cout<<i<<endl;
	    }
	}
	
	return 0;
}