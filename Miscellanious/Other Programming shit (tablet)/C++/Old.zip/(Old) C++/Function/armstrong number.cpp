#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
	int n;
    cin>>n;
    int check = n;
    
    int sum=0;
	while(n>0){
	    int lastdigit = n%10;
	    sum = sum + pow(lastdigit, 3);
	    n/=10;
	}
	
	if(sum==check){
	    cout<<"This is a armstrong number as it sum = "<<sum<<endl;
	}else{
	cout<<"This is not a armstrong number as it sum of cubic of its each digit is not equal to the orginail number and the sum = "<<sum<<endl;
	}
	
	return 0;
}