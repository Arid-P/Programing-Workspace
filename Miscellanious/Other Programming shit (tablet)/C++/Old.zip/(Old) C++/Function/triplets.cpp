#include <iostream>
#include <cmath>
using namespace std;

void check(int n1, int n2, int n3)
{
    int n1s = n1 * n1;
    int n23s = (n2 * n2) + (n3 * n3);

    if (n1s == n23s)
    {
        cout << n1 << " " << n2 << " " << n3 << " are pythogram triplets" << endl;
    }
    else
    {
        cout << " are not pythogram triplets" << endl;
    }
    return;
}

int main(int argc, char *argv[])
{
    int a, b, c;
    cout << "Entet the the largest value" << endl;
    cin >> a >> b >> c;
    
    check(a, b, c);

    return 0;
}