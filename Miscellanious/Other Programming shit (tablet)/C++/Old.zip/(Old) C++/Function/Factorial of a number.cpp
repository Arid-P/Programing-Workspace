#include <iostream>
using namespace std;

int factorial(int num)
{
    int fact = 1;
    for(int i=1; i<=num; i++){
        fact *= i;
    }
    return fact;
}
int main(int argc, char *argv[])
{
	int n, m;
	cin>>n>>m;
	
	cout<<"Factorial of "<<n<<" = "<<factorial(n)<<endl<<endl;
	cout<<"Factorial of "<<m<<" = "<<factorial(m)<<endl<<endl;
	
	return 0;
}

/* x! = x((x-1)!)
 x=5 then by x((x-1)!)
   = 5((5-1)!)
   = 5(4!)
   = 5 * 24
   = 120 */