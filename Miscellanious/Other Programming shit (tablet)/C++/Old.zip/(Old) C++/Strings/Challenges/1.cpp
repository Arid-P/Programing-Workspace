#include <iostream>
#include <string>

using namespace std;

void uppercase(string a)
{
  for(int i=0; i<a.size(); i++){
      if(a[i] >= 'a' && a[i] <= 'z'){
        a[i] -= 32;
      }
    }
    
    cout << "In Uppercase is " << a << endl;
  
  return;
}

void lowercase(string a)
{
    for(int i=0; i<a.size(); i++){
      if(a[i] >= 'A' && a[i] <= 'Z'){
        a[i] += 32;
      }
    }
    
    cout << "In lowercase is " << a <<endl;
    
    return;
}

void inverted(string a)
{
    for(int i=0; i<a.size(); i++){
      if(a[i] >= 'A' && a[i] <= 'Z'){
        a[i] += 32;
      }
      else if(a[i] >= 'a' && a[i] <= 'z'){
        a[i] -= 32;
      }
    }
    
    cout << "In inverted is " << a << endl;
   
    return;
}

int main(){
    string a = "aRIDAMAN pATEL";
    
    // 'lowercase' - 'uppercase' = 32
    
    lowercase(a);
    uppercase(a);
    inverted(a);
    
    return 0;
}