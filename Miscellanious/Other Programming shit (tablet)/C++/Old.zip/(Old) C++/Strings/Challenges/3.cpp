#include <iostream>
#include <string>

using namespace std;

void max(int freq[], string a)
{
  int maxF = 0;
  int r;
  for(int i=0; i<a.size(); i++)
    if(maxF < freq[i]){
      maxF = freq[i];
      r = i;
    }
  
  cout << a[r] << " = " << maxF << endl;
  return;
}

void cal(string a)
{
  int freq[a.size()];
  
  for(int i=0; i<a.size(); i++)
    freq[i] = 0;
  
  
  for(int i=0; i<a.size(); i++){
    for(int j=i; j<a.size(); j++){
      if(a[i] == a[j]){
        freq[i]++;
      }
    }
  }
  
  max(freq, a);
  return;
}



string lowercase(string a)
{
    for(int i=0; i<a.size(); i++){
      if(a[i] >= 'A' && a[i] <= 'Z'){
        a[i] += 32;
      }
    }
    return a;
}

int main()
{
  string a = "AbdbAgdgeAjeAeiAqoAudTRArhA";
  a = lowercase(a);
  cal(a);
  
  return 0;
}