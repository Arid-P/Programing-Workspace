#include <iostream>
#include <string>

using namespace std;

int main()
{
   string a = "53214";
    
    sort(a.begin(), a.end(), greater<int>());
  
  cout << a << endl;
  
  // like this also
  
  sort(a.begin(), a.end());
   
   for(int i=1; i<=a.size()/2; i++){
     int temp = a[i-1];
     a[i-1] = a[a.size()-i];
     a[a.size()-i] = temp;
  }
  
  cout << a << endl;
  
  return 0;
}