#include <iostream>
#include <string>

using namespace std;

int main()
{
    string s1 = "Ah_RAJ";
    
    s1.insert(1, "NS");
    
    cout << s1 << endl;
    
    cout << s1.size() << endl << endl;
    
    for(int i=0; i<s1.length(); i++)
    {
        cout << s1[i] << endl;
    }
    
    return 0;
}