#include <iostream>
#include <string>

using namespace std;

int main()
{
    string s1 = "nincompoop";
    
    string s = s1.substr(6, 4);
    
    cout << s << endl; 
    
    s1 = "678";
    int x = stoi(s1);
    
    cout << x+2 << endl;
    
    cout << to_string(x) + "2" << endl;
    
    return 0;
}