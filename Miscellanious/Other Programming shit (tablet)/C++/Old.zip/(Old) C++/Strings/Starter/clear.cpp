#include <iostream>
#include <string>

using namespace std;

int main()
{
    string abc = "ssjjfdgsjtvdddbbsjhr ythsbe";
    abc.clear();
    cout << abc;
    
    return 0;
}