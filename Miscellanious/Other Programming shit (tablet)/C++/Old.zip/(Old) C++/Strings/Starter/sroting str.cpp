#include <iostream>
#include <string>
#include <algorithm> // for sorting

using namespace std;

int main()
{
    string s = "ridnfqplsr";
    cout << s << endl;
    
    sort(s.begin(), s.end());
    
    cout << s << endl;
    return 0;
}