#include <iostream>
#include <string>

using namespace std;

int main()
{
    string s1 = "fam", s2 = "ily";
    
    cout << s1 + s2 << endl << endl;
    s1.append(s2);
    
    cout << s1 << endl << endl;
    
    
    cout << s1[3];
    
    return 0;
}