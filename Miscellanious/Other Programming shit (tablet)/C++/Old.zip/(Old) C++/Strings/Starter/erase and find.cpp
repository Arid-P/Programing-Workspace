#include <iostream>
#include <string>

using namespace std;

int main()
{
    string s1 = "ANSH_RAJ";
    cout << s1 << endl;
    // erase
    s1.erase(3, 3);
    
    cout << s1 << endl;
    
    // find
    cout << s1.find("RAJ") << endl;
    
    return 0;
}