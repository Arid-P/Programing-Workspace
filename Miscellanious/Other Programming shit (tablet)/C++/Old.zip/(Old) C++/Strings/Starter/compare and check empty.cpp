#include <iostream>
#include <string>

using namespace std;

int main()
{
    string s1 = "abc", s2 = "xyz";
    cout << s2.compare(s1) << endl << endl;
    // if value comrs out positive then s2 is bigger
    // if value comrs out negative then s1 is bigger
    //if 0 then both are equal
    
    cout << s1 << endl;
    s1.clear();
    
    if(s1.empty())
        cout << "string is empty" << endl;
    else
        cout << "string is not empty" << endl;
    
    return 0;
}