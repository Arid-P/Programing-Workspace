#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
	cout<<"Don't enter any number greater than 15"<<endl;
	int n;
	cin>>n;
	
	for(int i=1; i<=n; i++){
	    int space = n - i;
	    for(int j=1; j<=space; j++){
	        cout<<" ";
	    }
	    
	    for(int j=1; j<=n; j++){
	        cout<<"* ";
	    }
	    //cout<<"/ Aridaman Patel ";// for fun only
	    cout<<endl;
	}
	return 0;
}