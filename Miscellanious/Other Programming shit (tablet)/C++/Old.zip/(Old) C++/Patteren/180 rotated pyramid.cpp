#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
	int i, j, row, nr;
	cin>>row;
	
	//outerloop
	for(i=1; i<=row; i++){
	    //inner loop 1
	    nr = row - i;
	    for(j=1; j<=nr; j++){
	        cout<<" ";
	    }//inner loop 1 ends
	    
	    //inner loop 2
	    for(j=1; j<=i; j++){
	        cout<<"*";
	    }//inner loop 2 ends
	    cout<<endl;
	}//outer loop ends
}