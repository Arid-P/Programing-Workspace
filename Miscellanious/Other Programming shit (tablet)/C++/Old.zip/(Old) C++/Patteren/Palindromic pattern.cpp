#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
	int n, d=0;
	cin>>n;
	
	for(int i=1; i<=n; i++){
	    int space = n - i;
	    for(int j=1; j<=space; j++){
	        cout<<" ";
	    }
	    
	    for(int j=1; j<=i; j++){
	        int diff = i - d;
	        if(diff >= 1){
	        cout<<diff<<" ";
	        }
	        d++;
	    }
	    
	    for(int j=2; j<=i; j++){
	        cout<<j<<" ";
	    }
	    cout<<endl;
	}
	
	return 0;
}
//unable to complete by myself 