#include <iostream>
#include <cmath>
using namespace std;

void NCR(int n, int r)
{
    int i, nr = n-r;
    
    int fofn = 1;
    for(i=1; i<=n; i++){
        fofn *= i;
    }
    
    int fofr = 1;
    for(i=1; i<=r; i++){
        fofr *= i;
    }
    
    int fofnr = 1;
    for(i=1; i<=nr; i++){
        fofnr *= i;
    }
    
    int result = fofn / (fofnr * fofr);
    
    cout<<"nCr of "<<n<<" and "<<r;
    cout<<" = "<<result<<endl;
}

int main(int argc, char *argv[])
{
	int n,r;
    cout<<"Value of n = ";
    cin>>n;
    cout<<endl;
    
    cout<<"Value of r = ";
    cin>>r;
    cout<<endl;
	
	NCR(n,r);
	
	return 0;
}