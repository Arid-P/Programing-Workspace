#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    int i = 1, j = 1, s = 1, su = 2, n;
    cin >> n;
    
    
    for (; i <= n;)
    {
        for (; j <= s;)
        {
            cout << j << " ";
            j++;
        }
        s += su;
        ++su;
        cout << endl;
        i++;
        if(j>n){
            break;
        }
    }
}