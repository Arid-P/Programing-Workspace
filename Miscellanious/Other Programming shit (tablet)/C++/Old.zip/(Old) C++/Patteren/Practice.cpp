#include <iostream>

using namespace std;

void pattern(int n)
{
    int i, j;
    
    for(i=1; i<=n; i++)
    {
        int space = n - i;
        for(j=1; j<=space; j++)
        {
            cout << " ";
        }
        
        for(j=1; j<=i; j++){
            cout << " *";
        }
        cout << endl;
    }
    
    return;
}

int main()
{
    int n;
    cin >> n;
    pattern(n);
    
    return 0;
}