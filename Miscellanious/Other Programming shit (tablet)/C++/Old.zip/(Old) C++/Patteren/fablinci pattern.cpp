#include <iostream>
#include <cmath>
using namespace std;

int pattern(int n)
{
    int num1 = 0;
    int num2 = 1;
    int num3;
        
    for(int i=1; i<=n; i++){     
        cout<<num1<<", ";
        num3 = num1 + num2;
        num1 = num2;
        num2 = num3;
    }
    
    return 0;
}

int main(int argc, char *argv[])
{
	int z;
    cin>>z;

	pattern(z);
	
	return 0;
});
	
	return 0;
}