#include <iostream>
#include <cmath>
using namespace std;

int facto(int i)
{
    int factorial = 1;
    for(int j=1; j<=i; j++){
        factorial *= j;
    }
    return factorial;
}


int main(int argc, char *argv[])
{
	int n;
	cin>>n;
	
	for(int i=0; i<=n; i++){
	    for(int j=0; j<=i; j++){
	        int ans = facto(i) / (facto(j) * facto(i - j));
	        cout<<ans<<" ";
	    }
	    cout<<endl;
	}
	
	return 0;
}