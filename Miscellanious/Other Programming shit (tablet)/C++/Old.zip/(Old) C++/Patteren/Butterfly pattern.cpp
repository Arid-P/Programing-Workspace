 #include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
	cout<<"please don't enter any number above 22"<<endl;
	int n;
	cin>>n;
	
	//first half starts
	for(int i=1; i<=n; i++){
	 for(int j=1; j<=i; j++){
	     cout<<"*";
	 }
	 
	 int space = 2*n - 2*i;
	 for(int j=1; j<=space; j++){
	    cout<<" ";
	 }
	 
	 for(int j=1; j<=i; j++){
	     cout<<"*";
	 }
	 cout<<endl;
	}
	//first half ends
	
	//second half starts
    for(int i=n; i>=1; i--){
	 for(int j=1; j<=i; j++){
	     cout<<"*";
	 }
	 
	 int space = 2*n - 2*i;
	 for(int j=1; j<=space; j++){
	    cout<<" ";
	 }
	 
	 for(int j=1; j<=i; j++){
	     cout<<"*";
	 }
	 cout<<endl;
	}
	//second half ends
	return 0;
}