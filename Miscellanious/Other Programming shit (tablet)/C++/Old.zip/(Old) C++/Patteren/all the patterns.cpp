#include <iostream>
#include <cmath>
using namespace std;

void zopattern()
{
   int n;
   cin>>n;
	
   for(int i=1; i<=n; i++){
	  for(int j=1; j<=i; j++){
	     int sum = i + j;
	     double  div = sum % 2;
	      if(div == 0){
	          cout<<"1 ";
	      }
	      else{
	          cout<<"0 ";
	      }
	   }
	    cout<<endl;
   }
	    return;
}


void oezpattern()
{
    int i, j, row, nr;
	cin>>row;
	
	//outerloop
	for(i=1; i<=row; i++){
	    //inner loop 1
	    nr = row - i;
	    for(j=1; j<=nr; j++){
	        cout<<" ";
	    }//inner loop 1 ends
	    
	    //inner loop 2
	    for(j=1; j<=i; j++){
	        cout<<"*";
	    }//inner loop 2 ends
	    cout<<endl;
	}//outer loop ends
}

void butterfly()
{
    
cout<<"please don't enter any number above 22"<<endl;
	int n;
	cin>>n;
	
	//first half starts
	for(int i=1; i<=n; i++){
	 for(int j=1; j<=i; j++){
	     cout<<"*";
	 }
	 
	 int space = 2*n - 2*i;
	 for(int j=1; j<=space; j++){
	    cout<<" ";
	 }
	 
	 for(int j=1; j<=i; j++){
	     cout<<"*";
	 }
	 cout<<endl;
	}
	//first half ends
	
	//second half starts
    for(int i=n; i>=1; i--){
	 for(int j=1; j<=i; j++){
	     cout<<"*";
	 }
	 
	 int space = 2*n - 2*i;
	 for(int j=1; j<=space; j++){
	    cout<<" ";
	 }
	 
	 for(int j=1; j<=i; j++){
	     cout<<"*";
	 }
	 cout<<endl;
	}
	//second half ends
}

void facpattern()
{
    int n;
    cin>>n;
    
    int num1 = 0;
    int num2 = 1;
    int num3;
        
    for(int i=1; i<=n; i++){     
        cout<<num1<<", ";
        num3 = num1 + num2;
        num1 = num2;
        num2 = num3;
    }
    return;
}

void ftriangle()
{
    int i = 1, j = 1, s = 1, su = 2, n;
    cin >> n;
    
    
    for (; i <= n;)
    {
        for (; j <= s;)
        {
            cout << j << " ";
            j++;
        }
        s += su;
        ++su;
        cout << endl;
        i++;
        if(j>n){
            break;
        }
    }
    return;
}

void halfpbnum()
{
    int n, i, j;
	cin>>n;
	
	for(i=1; i<=n; i++){
	    for(j=1; j<=i; j++){
	        cout<<i<<" ";
	    }
	    cout<<endl;
	}
	return;
}

void invertedp()
{
    int n;
    cin>>n;
    
    for(int i=n; i>=1; i--){
        for(int j=1; j<=i; j++){
            cout<<j<<' ';
        }
        cout<<endl;
    }
    return;
}

void inpp()
{
    int row, i, j;
	cin>>row;
	
	//outer loop starts
	for(i=row; i>=1; i--){
	    //inner loop starts
	    for(j=1; j<=i; j++){
	        cout<<"*";
	    }//inner loop ends
	    cout<<endl;
	}//outer loop ends
	return;
}

void invertpatt()
{
    int n;
    cin>>n;
    
    for(int i=n; i>=1; i--){
        for(int j=1; j<=i; j++){
            cout<<j<<' ';
        }
        cout<<endl;
    }
    return;
}

void inverted()
{
    int row, col, i, j;
cout<<"Enter how many row do you want"<<endl;
cin>>row;
cout<<endl<<endl;

   //outer loop 
	for(i = row; i>=1; i--){
			//inner loop
			for(j=1; j<=i; j++){
				cout<<"*";
			}//inner loop ends
			cout<<endl;
     	}
     	//outer loop ends
    return;
}

int facto(int i)
{
    int factorial = 1;
    for(int j=1; j<=i; j++){
        factorial *= j;
    }
    return factorial;
}

void ncrpattern()
{
    int n;
	cin>>n;
	
	for(int i=0; i<=n; i++){
	    for(int j=0; j<=i; j++){
	        int ans = facto(i) / (facto(j) * facto(i - j));
	        cout<<ans<<" ";
	    }
	    cout<<endl;
	}
	return;
}

void np()
{
    cout<<"Don't enter any number greater than 15"<<endl;
	int n;
	cin>>n;
	
	for(int i=1; i<=n; i++){
	    int space = n - i;
	    for(int j=1; j<=space; j++){
	        cout<<" ";
	    }
	    
	    for(int j=1; j<=i; j++){
	        cout<<j<<" ";
	    }
	    //cout<<"/ Aridaman Patel ";// for fun only
	    cout<<endl;
	}
	return;
}

void ppattern()
{
    int n, d=0;
	cin>>n;
	
	for(int i=1; i<=n; i++){
	    int space = n - i;
	    for(int j=1; j<=space; j++){
	        cout<<" ";
	    }
	    
	    for(int j=1; j<=i; j++){
	        int diff = i - d;
	        if(diff >= 1){
	        cout<<diff<<" ";
	        }
	        d++;
	    }
	    
	    for(int j=2; j<=i; j++){
	        cout<<j<<" ";
	    }
	    cout<<endl;
	}
    return;
}

void rp()
{
    cout<<"Don't enter any number greater than 15"<<endl;
	int n;
	cin>>n;
	
	for(int i=1; i<=n; i++){
	    int space = n - i;
	    for(int j=1; j<=space; j++){
	        cout<<" ";
	    }
	    
	    for(int j=1; j<=n; j++){
	        cout<<"* ";
	    }
	    //cout<<"/ Aridaman Patel ";// for fun only
	    cout<<endl;
	}
	return;
}


int main(int argc, char *argv[])
{
    int n;
    cin>>n;
    
    switch(n)
    {
      case 1 :
          zopattern();
        break;
        
      case 2 :
          oezpattern();
        break;
      
     case 3 :
          butterfly();
        break;
      
      case 4 :
          facpattern();
        break;
      
      case 5 :
          ftriangle();
        break;
      
      case 6 :
          halfpbnum();
        break;
        
      case 7 :
          invertedp();
        break;
      case 8 :
          inpp();
        break;
      case 9 :
          invertpatt();
        break;
      case 10 :
          inverted();
        break;
      case 11 :
          ncrpattern();
        break;
      case 12 :
          np();
        break;
      case 13 :
          ppattern();
        break;
      case 14 :
          rp();
        break;
    }
	return 0;
}