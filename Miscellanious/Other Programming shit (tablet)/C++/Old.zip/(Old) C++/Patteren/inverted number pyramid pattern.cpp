#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
	int row, i, j;
	cin>>row;
	
	//outer loop starts
	for(i=row; i>=1; i--){
	    //inner loop starts
	    for(j=1; j<=i; j++){
	        cout<<"*";
	    }//inner loop ends
	    cout<<endl;
	}//outer loop ends
}