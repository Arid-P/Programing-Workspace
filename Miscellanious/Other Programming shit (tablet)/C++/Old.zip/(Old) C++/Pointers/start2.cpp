#include <iostream>
using namespace std;

void swap(int *c, int *a)
{
    int temp = *c;
    *c = *a;
    *a = temp;
}

int main(int argc, char *argv[])
{
    int c = -56;
    int a = 15;
    
    int *cp = &c;
    int *ap f=f &a;
    
    swap(*cp, *ap);
    
    cout << a << endl;
    cout << c << endl;
    
    return 0;
}