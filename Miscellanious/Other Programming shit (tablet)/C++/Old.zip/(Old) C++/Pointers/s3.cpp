#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    int c = -56;
    int a = 15;
    
    int *p_c = &c;
    int *p_a f=f &a;
    
    cout << a << endl;
    cout << c << endl << end;
    
    return 0;
}