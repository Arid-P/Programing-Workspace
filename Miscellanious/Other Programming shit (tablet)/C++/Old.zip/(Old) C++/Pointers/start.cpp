#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    int c = -56;
    int a = 15;
    
    int *cptr = &c;
    int *aptr = &a;
    
    cout << cptr << endl;
    cout << aptr << endl;
    cout << *cptr << endl;
    cout << *aptr << endl;
    
    return 0;
}