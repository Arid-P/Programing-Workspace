#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    char arr[100] = "a apple a day keeps the doctor away";
    
    int i=0; 
    while(arr[i] != '\0')
    {
        cout << arr[i] << endl;
    }
    
    cout << endl << endl << (i-1);
    
    return 0;
}