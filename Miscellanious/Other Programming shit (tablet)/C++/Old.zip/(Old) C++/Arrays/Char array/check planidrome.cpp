#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    int n;
    cin >> n;
    
    char arr[n+1];
    cin >> arr;
    
    bool check = 1;
    for(int i=0; i<n; i++)
    {
        if(arr[i] != arr[n-1-i])
        {
            check = 0;
            break;
        }
    }
    
    if(check)
    {
       cout << arr << " is a planidrome\n";
       return 1;
    }
    else
    {
        cout << arr << " is not a planidrome\n";
       return 0;
    }
}