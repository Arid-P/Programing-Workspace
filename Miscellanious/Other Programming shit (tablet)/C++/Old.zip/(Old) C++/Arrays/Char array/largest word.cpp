#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    int n;
    cin >> n;
    cin.ignore();
    
    char arr[n+1];
    
    cin.getline(arr, n);
    cin.ignore();
    
    int i = 0;
    int cuurlen = 0, maxlen = 0;
    
}