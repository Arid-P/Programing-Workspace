#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    int rows, column;
    cout << "Enter the row number" << endl;
    cin >> rows;
    cout << "Enter the column number" << endl;
    cin >> column;

    int arr[rows][column];
    
    cout << "\nEnter the value of the array\n";
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < column; j++) {
            cin >> arr[i][j];
        }
    }


    cout << "\nThe Matrix is \n";
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < column; j++) {
            cout << arr[i][j] << "  ";
        }
        cout << endl;
    }
    cout << "\n";
    
    int find_num;
    cout << "\nNumber of which cordinates yoy want\n";
    cin >> find_num;
    
    int r = 0, c = column - 1;
    while(r <= rows && c >= 0)
    {
        if(arr[r][c] == find_num)
        {
            cout << "\n" << find_num << " is found at cordinates ";
            cout << "(" << r << "," << c << ")\n";
            return 1;
        }
        else if(arr[r][c] > find_num)
        {
            r++;
        }
        else if(arr[r][c] < find_num)
        {
            c--;
        }
    }
    
    cout << "\n Element not found";
    
    return 0;
}