#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    cout << "Enter the row number" << endl;
    cin >> rows;
    cout << "Enter the column number" << endl;
    cin >> column;
    
    int arr[rows][column];
    
    cout << "\nEnter the value of the array\n";
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < column; j++) {
            cin >> arr[i][j];
        }
    }
    
    cout << "\nThe Original Matrix is \n";
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < column; j++) {
            cout << arr[i][j] << "  ";
        }
        cout << endl;
    }
    cout << "\n";
    
    for(int i=0; i<3; i++)
    {
        for(int j=0; j<3; j++)
        {
            int temp = arr[i][j];
            arr[i][j] = arr[j][i];
            arr[j][i] = temp;
        }
    }
    
    cout << "\nThe transpose matrix is\n\n";
    for(int i=0; i<3; i++)
    {
        for(int j=0; j<3; j++)
        {
            cout << arr[i][j] << "  ";
        }
        cout << "\n";
    }
    return 0;
}