#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    int row1, column1, row2, column2, new_row, new_column;
    
    cout << "Enter the row number\n";
    cin >> row1;
    cout << "Enter the column number\n";
    cin >> column1;
    
    row2 = column1;
    cout << "Enter the column number of the second array\n";
    cin >> column2;
    
    new_row = row1;
    new_column = column2;
    
    int a1[row1][column1];
    int a2[row2][column2];
    int new_a[new_row][new_column];
    
    cout << "\nEnter the value of the first matrix\n";
    for(int i = 0; i < row1; i++) {
        for(int j = 0; j < column1; j++) {
            cin >> a1[i][j];
        }
    }
    
    cout << "\nEnter the value of the second matrix\n";
    for(int i = 0; i < row2; i++) {
        for(int j = 0; j < column2; j++) {
            cin >> a2[i][j];
        }
    }
    
    
    //Matrix multiplication
    for(int i=0; i<row1; i++)
    {
        for(int j=0; j<column1; j++)
        {
            int sum = 0;
            int pro;
            for(int k=0; k<row2; k++)
            {
                pro = a1[i][k] * a2[k][j];
                sum += pro;
            }
            new_a[i][j] = sum;
        }
    }
    
    cout << "\n\nThe multipled matrix is\n";
    for(int i=0; i<new_row; i++)
    {
        for(int j=0; j<new_column; j++)
        {
            cout << new_a[i][j] << "  ";
        }
        cout << "\n";
    }
    
    return 0;
}