#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
    int rows, column;
    cout << "Enter the row number" << endl;
    cin >> rows;
    cout << "Enter the column number" << endl;
    cin >> column;

    int arr[rows][column];
    
    cout << "\nEnter the value of the array\n";
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < column; j++) {
            cin >> arr[i][j];
        }
    }


    cout << "\nThe Matrix is \n";
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < column; j++) {
            cout << arr[i][j] << "  ";
        }
        cout << endl;
    }
    cout << "\n";
    
    int row_start = 0, ro_end = rows - 1;
    int col_start = 0, co_end = column - 1;
    
    while(row_start <= ro_end && col_start <= co_end)
    {
        // 1:
        for(int col=col_start; col <= co_end; col++)
        {
            cout << arr[row_start][col] << "  ";
        }
        row_start++;
        
        //2:
        for(int row = row_start; row <= ro_end; row++)
        {
            cout << arr[row][co_end] << "  ";
        }
        co_end--;
        
        //3:
        for(int col=co_end; col >= col_start; col--)
        {
            cout << arr[ro_end][col] << "  ";
        }
        ro_end--;
        
        //4:
        for(int row = ro_end; row >= row_start; row--)
        {
            cout << arr[row][col_start] << "  ";
        }
        col_start++;
    }
    
    return 0;
}