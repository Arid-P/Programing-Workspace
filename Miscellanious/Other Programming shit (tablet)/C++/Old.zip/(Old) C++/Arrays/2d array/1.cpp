#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
    int row, col;
    cout << "Enter the row number" << endl;
    cin >> row;
    cout << "Enter the column number" << endl;
    cin >> col;

    int arr[row][col];
    
    cout << "\nEnter the value of the array\n"
    for(int i = 0; i < row; i++) {
        for(int j = 0; j < col; j++) {
            cin >> arr[i][j];
        }
    }


    cout << "\nThe Matrix is \n";
    for(int i = 0; i < row; i++) {
        for(int j = 0; j < col; j++) {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }
    cout << "\n";
    
    int num;
    cout << "Enter the number of which cordinates you want\n";
    cin >> num;
    
    bool check = true;
    for(int i = 0; i < row; i++)
    {
        for(int j = 0; j < col; j++)
        {
            if(arr[i][j] == num)
            {
               cout << "\nCordinates of " << num << " is ";
               cout << "(" << i << "," << j << ")\n";
               check = false;
               break;
            }
        }
    }
    
    if(check)
    {
        cout << "\nNot found";
    }
    
    return 0;
}