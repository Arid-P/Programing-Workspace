#include <iostream>
using namespace std;

int main()
{
  int size;
    cout << "Enter the size of the array" << endl;
    cin >> size;
    
    int arr[size];
    
    cout << "Enter the value" << endl;
    for(int i=0; i<size; i++)
    {
      cin >> arr[i];
    }
    
    int num = 0;
    int index = 0;
    int times = 1;
    
    for(int i=0; i<size; i++)
    {
      bool check = 0;
      for(int j=1; j<size; j++)
      {
        if(arr[i] == arr[j])
        {
          check = 1;
          times++;
        }
        // if ends
      }
      // loop ends
      if(check == 1)
      {
        index = i;
        num = arr[index];
        break;
      }
      // if ends
    }
    //loop ends
    
    cout << "number = " << num << endl;
    cout << "index = " << index << endl;
    cout << "times = " << times << endl;
    
    return 0;
}