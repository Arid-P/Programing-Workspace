#include <iostream>
using namespace std;

int main()
{
    int size;
    cout << "Enter the size of the array" << endl;
    cin >> size;
    cout << endl;
    
    int arr[size];
    
    cout << "Enter the value" << endl;
    for(int i=0; i<size; i++)
    {
      cin >> arr[i];
    }
    
    for (int i=1; i<size; i++)
    {
      int temp;
      int n1 = 0;
      int n2 = n1 + 1;
      int ni = size - i;
      for(int j=1; j<=ni; j++)
      {
        if(arr[n1] > arr[n2])
        {
          temp = arr[n2];
          arr[n2] = arr[n1];
          arr[n1] = temp;
        }
        n1++;
        n2++;
      }
    }
    
    cout << endl;
    cout << "This is our new storted array" << endl;
    for(int i=0; i<size; i++)
    {
      cout << arr[i] << ", ";
    }
    cout << endl;
    
    int check = 0;
    bool check1 = 0;
    for(int i=0; i<size; i++)
    {
      int index = i;
      while(arr[i] >= 0)
      {
        if(arr[t] != check)
        {
          cout << endl;
          cout << "The missing number is " << check;
          cout << " at index " << index << endl;
          check1 = 1;
          break;
        }
        //if ends
        index++;
        check++;
      }
      // while ends
      if(check)
      {
        break;
      }
      //if ends
    }
    // FOR ends
    
    return 0;
}