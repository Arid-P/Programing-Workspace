#include <iostream>
using namespace std;

int main()
{
  int size;
    cout << "Enter the size of the array" << endl;
    cin >> size;
    
    int arr[size];
    
    cout << endl << "Enter the value" << endl;
    for(int i=0; i<size; i++)
    {
      cin >> arr[i];
    }
    
    int original_Sum;
    cout << endl << "Enter the sum" << endl;
    cin >> original_Sum;
    
    int starting_Index;
    int ending_Index;
    
    int sum = 0;
    bool check = 1;
    
    for(int i=0; i<size; i++)
    {
      starting_Index = i;
      sum = arr[i];
      
      for(int j=i+1; j<size; j++)
      {
        sum += arr[j];
        ending_Index = j;
        
        if(sum == original_Sum)
        {
          check = 0;
          break;
        }
        //if ends
      }
      if(check != 1)
      {
        break;
      }
      //loop ends
    }
    
    if(check != 1)
    {
      cout << endl << "Starting Index = " << starting_Index << endl;
      cout << "Ending Index = " << ending_Index << endl;
    }
    else
    {
      cout << endl << "This value is not posible" << endl;
    }
    
    return 0;
}