#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
int row, col, i, j;
cout<<"Enter how many row do you want"<<endl;
cin>>row;
cout<<endl<<endl;

   //outer loop 
	for(i = row; i>=1; i--){
			//inner loop
			for(j=1; j<=i; j++){
				cout<<"*";
			}//inner loop ends
			cout<<endl;
     	}
     	//outer loop ends
}