#include <iostream>
using namespace std;

int main()
{
    int size = 4;
    int arr[4] = {-1, 2, 7, 4};
    
    for(int j=0; j<size; j++)
    {
      int counter = j + 1;
      int index = j;
      for(int i=0; i<counter; i++)
      {
        while(index < counter)
        {
          cout << arr[index] << ", ";
          index++;
        }
        cout << endl;
      }
      counter = 1;
    }
    
    return 0;
}
    /*cout << "Enter the value" << endl;
    for(int i=0; i<size; i++)
    {
      cin >> arr[i];
    }
    cout << "Enter the size of the array" << endl;
    cin >> size;
    cout << endl*/