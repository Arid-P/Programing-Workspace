#include <iostream>
using namespace std;

int main()
{
    int size;
    cout << "Enter the size of the array" << endl;
    cin >> size;
    
    int arr[size];
    
    cout << "Enter the value" << endl;
    for(int i=0; i<size; i++)
    {
      cin >> arr[i];
    }
    
    int mx = arr[0];
  
    for(int i=1; i<size; i++)
    {
      mx = max(mx, arr[i]);
    }
  
    cout << "Maximum = " << mx;
    
    return 0;
}