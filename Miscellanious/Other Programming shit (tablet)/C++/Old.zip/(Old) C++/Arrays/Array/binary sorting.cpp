#include <iostream>
using namespace std;

int main()
{
    int n;
    cout<<"Enter the number of values that the array will have ";
    cin>>n;
    
    int array[n];
    cout<<"Enter the values of the arrays"<<endl;
    for(int i=0; i<n; i++){
      cin>>array[i];
    }
    
    int key;
    cout<<"Enter the value of which index you want ";
    cin>>key;
    
    //binaryseacrh starts
    int s = 0;
    int e = n;
    int index;
    bool check = 1;
    
    while(s<=e){
      int mid = (s + e) / 2;
        
      if(array[mid] == key){
        index = mid;
        check = 1;
        break;
      }
      else if(array[mid] > key){
        e = mid;
        check = 0;
      }
      else{
        s = mid;
        check = 0;
      }
    }
    //binaryseacrh ends
    
    if(check == 0){
      cout<<endl<<"-1"<<endl;
    }
    else{
      cout<<endl<<index<<endl;
    }
    
    return 0;
}