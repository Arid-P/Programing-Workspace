#include <iostream>
using namespace std;

void sorting(int arr[], int size)
{
  for(int i=0; i<size; i++){
    if(arr[i] > arr[i+1]){
      for(int j=0; j<size; j++){
        if(arr[i+1] < arr[j]){
          int temp = arr[i+1];
          arr[i+1] = arr[j];
          arr[j] = temp;
        }
        // inner if else finish
      }
      // inner if for loop finish
    }
    // outer if else finish
  }
  // outer if for loop finish
  
  for(int i=0; i<size; i++){
    cout << arr[i] << " ";
  }
  cout <<endl;
  
  return;
}

int main()
{
    int size;
    cout << "Enter the size of which array you want" << endl;
    cin >> size;
    
    int arr[size];
    
    cout << "Enter the value of the array" << endl;
    for(int i=0; i<size; i++){
        cin >> arr[i];
    }

    sorting(arr, size);
  
    return 0;
}