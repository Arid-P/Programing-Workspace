#include <iostream>
#include <climits>
using namespace std;

void indexscearch(int array[], int n, int key)
{
    for(int i=0; i<=n; i++){
        if(array[i] == key){
            cout << "cordinate is " i << endl;
        }
    }
    cout << "Value is not present in the array" << endl;
    return;
}

int sort(int array[], int n)
{
  for(int i=0; i<size; i++){
    if(arr[i] > arr[i+1]){
      for(int j=0; j<size; j++){
        if(arr[i+1] < arr[j]){
          int temp = arr[i+1];
          arr[i+1] = arr[j];
          arr[j] = temp;
        }
      }
    }
  }
  
  return array;
}

int main()
{
    int n, key;
    cout << "ENter the size of the array" << endl;
    cout << endl;
    
    int array[n];
    cout << "Enter the values of the arrays" << endl;
    for(int i=0; i<n; i++){
        cin>>array[i];
    }
    
    cout << "Enter the value of which cordinate to want" << endl;
    cin >> n >> key;

    array = sort(array, n);
    
    indexscearch(array, n, key);
    
    return 0;
}