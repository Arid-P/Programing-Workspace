#include <iostream>
#include <climits>
using namespace std;

int indexscearch(int array[], int n, int key)
{
    for(int i=0; i<=n; i++){
        if(array[i] == key){
            return i;
        }
    }
    return -1;
}

int main()
{
    int n, key;
    cin>>n>>key;
    cout<<endl;
    
    int array[n];
    cout<<"Enter the values of the arrays"<<endl;
    for(int i=0; i<n; i++){
        cin>>array[i];
    }

    cout<<indexscearch(array, n, key)<<endl;
    return 0;
}