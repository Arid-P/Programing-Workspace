#include <iostream>
#include <string>
using namespace std;

bool next(string op, int *result)
{
    if(op == "=" || op == "e"){
	    cout << endl << *result;
	    return true;
	}
	
	int c;
	cout << "\nEnter the next number" << endl;
	cin >> c;
	
    if(op == "+" || op == "a"){
	    *result += c;
    }
    else if(op == "-" || op == "s"){
	    *result -= c;
	}
    else if(op == "*" || op == "m"){
	    *result *= c;
	}
    else if(op == "/" || op == "d"){
	    *result /= c;
	}
    else if(op == "%" || op == "r"){
	    *result /= c;
	}
	else{
	    cout << "Invalid Option" << endl;
	    return true;
	}
	
	return false;
}

int main(int argc, char *argv[])
{
    int a, b, result1;
    string op;
    
	cout << "Enter a number\n";
	cin >> a;
	
	cout << "\n\nEnter an operation like\n+ or a for additon\n - or s for";
	cout << "subtraction\n* or m for multiplication\n/ or d for division\n% or r for";
	cout << "\nremender\nRemember this and it can only excute these opretion\n";
	cin >> op;
	
	cout << "\nEnter the second number\n";
	cin >> b;
	
	if(op == "+" || op == "a"){
	    result1 = a + b;
	}
	else if(op == "-" || op == "s"){
	    result1 = a - b;
	}
	else if(op == "*" || op == "m"){
	    result1 = a * b;
	}
	else if(op == "/" || op == "d"){
	    result1 = a * b;
	}
	else if(op == "%" || op == "r"){
	    result1 = a * b;
	}
	else{
	    cout << "\nInvalid Option" << endl;
	    return 0;
	}
	
	int *result = &result1;
    
    
	for( ; ; ){
	    cout << "\nEnter the next opretion" << endl;
    cin >> op;
	    if(next(op, result)){
	        break;
	    }
	}
	
	return 1;
}