#include <iostream>
using namespace std;

float check(int n)
{
	for(int i=2; i<=n; i++){
	    float tot = n;
	    
	    if(n%i == 0){
	        
	        cout<< i <<" | "<< tot << endl << endl;
	        
	        tot = n/i;
	        
	        return tot;
	        
	    }
	    
	}

	return 0;
}

int main(int argc, char *argv[])
{
  for(int j=1; ; j++)
  {
	int n;
	cin>>n;
    int pro = n;
	
	int num = 1;
	for(int i=1; i<=n; i++)
	  { 
	    
	    if(pro == 0)
	    {
	        break;
	    }
	    
	    cout << num << ".      ";
	    pro = check(pro);
	    num++;
	    
	  }
	
  }
	
	return 0;
}
