#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    int n;
    cout << "Enter the number of values you want to input " << endl;
    cin >> n;
    
    int arr[n];
    
    cout << "Enter the values now" << endl;
    for(int i=0; i<n; i++)
    {
        cin >> arr[i];
    }
    
    int total = 0;
    for(int i=0; i<n; i++)
    {
        total += arr[i];
    }
    
    int average = total / n;
    
    cout << "The average = " << average << endl;
	
	return 0;
}