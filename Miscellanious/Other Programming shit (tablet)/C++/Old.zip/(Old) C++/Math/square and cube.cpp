#include <iostream>
using namespace std;

void Square_And_Cube(float value)
{
  float sq = value * value;
  float cu = value * value * value;
  
  cout << "Square of " << value << " = " << sq << endl;
  
  cout << "Cube of " << value << " = " << cu << endl << endl;
  
  return;
}

int main()
{
  int times;
  cout << "How many values do you want to enter ";
  cin >> times;
  
  for(int i=1; i<=times; i++)
  {
    float value;
    
    cout << "Enter the number of which you want square and cube of " << endl;
    cin >> value;
    
    cout << endl << endl;
    Square_And_Cube(value);
  }
  
  return 0;
}