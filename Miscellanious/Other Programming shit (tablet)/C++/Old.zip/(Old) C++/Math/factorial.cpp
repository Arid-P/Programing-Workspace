#include <iostream>
#include <cmath>
using namespace std;

void factorial(int n)
{
    int fact = 1;
    
    for(int i=1; i<=n; i++){
       fact = fact * i;
    }
    cout<<"Factorial of "<<n;
    cout<<" = "<<fact<<endl;
}

int main(int argc, char *argv[])
{
	int n;
	cin>>n;

    factorial(n);
	return 0;
}