#include <iostream>
#include <cmath>
using namespace std;

void sonn(int n)
{
    int sum; 
    for(int i=1; i<=n; i++){
       sum += i; 
    }
    cout<<sum;
    return;
}

int main(int argc, char *argv[])
{
	int n;
	cin>>n;
	
	sonn(n);
	
	return 0;
}sonn(n);
	
	return 0;
}