#include <iostream>
using namespace std;

int check(int  n)
{
	for(int  i=2; i<=n; i++){
	    int tot = n;
	    
	    if(n%i == 0){
	        
	        cout<< i <<" | "<< tot << endl << endl;
	        
	        tot = n/i;
	        
	        return tot;
	        
	    }
	    
	}

	return 0;
}

int  main(int  argc, char *argv[])
{
  for(float  j=1; ; j++)
  {
	float  n;
	cin>>n;
    float  pro = n;
	
	float  num = 1;
	for(float  i=1; i<=n; i++)
	  { 
	    
	    if(pro == 0)
	    {
	        break;
	    }
	    
	    cout << num << ".      ";
	    pro = check(pro);
	    num++;
	    
	  }
	
  }
	
	return 0;
}
