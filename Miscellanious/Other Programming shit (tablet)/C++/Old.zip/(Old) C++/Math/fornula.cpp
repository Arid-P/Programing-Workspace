#include <iostream>
using namespace std;

void print(int x, int x1, int y)
{
    int a, b, c, sum;
    sum = (y * (x1 + x)) + (x1 * x1);
//       x^2  = (y * (2x - y)) + (z)^2; while (x - y) = z;
    a = (x1 + x);
    b = y * a;
    c = x1 * x1;
    
     ///*
    cout << "\nSquare of " << x << "\n= ";
    cout << "(" << y << " * (" << x1 << " + " << x << ")) + (" << x1 << ")^2";
    cout << "\n= " << "(" << y << " * (" << a << ")) + " << c;
    cout << "\n= " << b << " + " << c;
    cout << "\n= " << sum << endl << endl;
     //*/
    
    //or
    
    //cout << "\nSquare of " << x << " = " << sum << endl;
    
    return;
}

void square(int x, int y, int x1)
{
    int s, s1, s2;
    
    s = x * x;
    s1 = y * y;
    s2 = x1 * x1;
    
    cout << "\nSquare of " << x1 << " = " << s2;
    cout << "\n\nSquare of " << y << " = " << s1 << endl;
    
    print(x, x1, y);
    
    return;
}


int main(int argc, char *argv[])
{
	for(int i=0; i<15; i++)
	{
		int x, y, x1;
		cout << "Enter the number\n";
		cin >> x;
		cout << "\nEnter the number till you know that number sqaure\n";
		cin >> y;
		
		x1 = x - y;
		cout << x << " - " << y << " = " << x1 << endl;
		
		square(x, y, x1);
	}
	
	return 0;
}