#include <iostream>

using namespace std;

bool check(int a)
{
  int num1, num3;
  
  num1 = a % 10;
  a /= 10;
  a /= 10;
  num3 = a % 10;
  
  if(num1 == num3){
    return true;
  }
  
  return false;
}

int main()
{
  int n;
  
  for(int i=11; i<=100; i++){
    n = 11 * i;
    if(check(n)){
      cout << "[" << n << "  " << i << "]   ";
    }
  }
  
  return 0;
}