#include <iostream>
#include <string>

using namespace std;

void check(string word, string rev)
{
  if(word == rev){
    cout << "plandromic" << endl;
  }
  else{
    cout << "not plandromic" << endl;
  }
  
  return;
}

void reverse(string word)
{
  string rev = "";
  int length = word.length();
  
  for(int i=length; i>=0; i--){
    rev += word[i];
  }
  
  check(word, rev);
  
  return;
}

int main()
{
  string word = "racecar";
  getline(cin, word);
  
  reverse(word);
  
  return 0;
}