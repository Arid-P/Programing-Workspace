#include <iostream>
using namespace std;

int main(){

float r, a, c, pi; /* r = radius  a = area 
c = circumfernce pi = 3.14*/
pi = 3.14;

cout<<"Enter the value of the radius of a circle"<<endl<<"Radius = ";
cin>>r;

a = pi * r * r;
c = 2 * pi * r;

cout<<"Area of the circle = "<<a<<endl;
cout<<"Circumference of the circle = "<<c<<endl;

return 0;
}