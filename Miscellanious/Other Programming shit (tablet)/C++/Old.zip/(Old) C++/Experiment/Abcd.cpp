#include <iostream>
#include <string
using namespace std;

string uppercase(string a)
{
  if(a >= "a" && a <= "z"){
    a[0] = a[0] - 32;
    return a;
  }
  else{
    return a;
  }
}

int main()
{
  string alp;
  
  cout << "Enter the alphabet of which number you want" << endl;
  cin >> alp;
  
  alp = uppercase(alp);
  string abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  
  for(int i=0; i<26; i++){
    if(alp[0] == abc[i]){
      cout << alp << " comes at " << (i+1) << endl << endl;
      main();
    }
  }
  
  return 0;
}