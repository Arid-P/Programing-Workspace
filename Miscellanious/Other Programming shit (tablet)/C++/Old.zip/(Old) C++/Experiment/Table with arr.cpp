#include  <iostream>
using namespace std;

void calp(int num, int multi)
{
int arr[multi];

for(int i=0; i<=multi; i++)
{
arr[i] = num * i;

cout << num <<" * " << i << " = " << arr[i];
cout << endl;
}

return;
}

int main()
{
int num, multi;
cin >> num >> multi;

calp(num, multi);

return 0;
}