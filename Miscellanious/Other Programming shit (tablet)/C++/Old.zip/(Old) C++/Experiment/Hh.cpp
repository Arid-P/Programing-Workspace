#include <iostream>
using namespace std;

void print(int size, int array[])
{
  for(int i=0; i<size; i++)
  {
      cout << array[i] << "    ";
  }
}

int main()
{
  int size;
    cout << "Enter the size of the array" << endl;
    cin >> size;
    
    int array[size];
    
    cout << "Enter the value" << endl;
    for(int i=0; i<size; i++)
    {
      cin >> array[i];
    }
    
    print(size, array[]);
    
    return 0;
}