#include <iostream>
using namespace std;

int main1(int n, int w)
{
    if(!(n >= 0)){
      return 0;
    }
    
    cout << "Week " << w << endl;
     w++;
    
    int i = 1;
    while(i<=7){
      float d = n - (1.5*i);
      cout << d << endl << endl;
      i++;
    }
    //n = n - (1.5*i);
   n = n - (1.5*(i-1));
   
    int k;
    cin>>k;
    
    main1(n, w);
}

int main()
{
  int n = 65.5;
  int w = 36;
  
  main1(n, w);
  
  return 0;
}