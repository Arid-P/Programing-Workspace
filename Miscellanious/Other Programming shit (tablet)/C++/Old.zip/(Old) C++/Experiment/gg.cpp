#include <iostream>
using namespace std;

int main()
{
    int n = 6;
    
    int array[6] = {1, 5, 3, 7, 5, 7}.
    
  //bubble sorting 
    //outer loop
    for(int i=1; i<n; i++){
     //inner loop
      while((n-i)>0){
        int n1 = 0;
        int n2 = 1;
        if(array[n1] > array[n2]){
          int temp = array[n1];
          array[n1] = array[n2];
          array[n2] = temp;
        }
        n1++;
        n2++;
      }
      //inner loop ends
    }
    //outer loop ends
    
    for(int i=0; i<n; i++){
      cout<<array[i]<<endl;
    }
    
    return 0;
}