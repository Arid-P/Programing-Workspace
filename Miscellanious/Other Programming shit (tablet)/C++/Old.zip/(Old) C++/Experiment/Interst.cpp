#include <iostream>

using namespace std;

int main()
{
  int p;
  cout << "Enter the amount" << endl;
  cin >> p;
  
  int t = 1;
  float r = 6.75;
  
  int i = (p * t * r) / 100;
  int fp =  p + i;
  
  cout << "interest = " << i << endl;
  cout << "final price = " << fp << endl << endl;
  
  if(p == 0){
    return 0;
  }
  
  main();
  
  return 0;
}