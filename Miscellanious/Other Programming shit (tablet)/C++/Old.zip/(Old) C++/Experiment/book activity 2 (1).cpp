#include <iostream>
using namespace std;

int main(){

float t, a, st;
st = 50;

float e, h, m, s, c, i;
char n;

for(int i=1; i<=st; i++){
cout<<"Enter the name and marks of english, hindi, math, science, computer out of 100 of student no. "<<i<<endl;

cout<<endl<<"Marks of english = ";
cin>>e;

cout<<endl<<"Marks of hindi = ";
cin>>h;

cout<<endl<<"Marks of math = ";
cin>>m;

cout<<endl<<"Marks of science = ";
cin>>s;

cout<<endl<<"Marks of computer = ";
cin>>c;

t = e + h + m + s + c;
a = t / 5;

cout<<endl<<"Name of the student is "<<n<<endl;
cout<<"total marks = "<<t<<"/500"<<endl;
cout<<"average = "<<a<<endl;
};

return 0;
}