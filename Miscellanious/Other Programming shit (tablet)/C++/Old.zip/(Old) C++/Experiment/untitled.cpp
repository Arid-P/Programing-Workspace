#include <iostream>
using namespace std;

int main()
{
  int size;
    cout << "Enter the size of the array" << endl;
    cin >> size;
    
    int arr[size];
    
    cout << "Enter the value" << endl;
    for(int i=0; i<size; i++)
    {
      cin >> arr[i];
    }
    
    for(int i=1; i<size; i++)
    {
      for(int j=0; j<size; j++)
      {
        int n1 = 0;
        int n2 = 1;
        
        if(arr[n1] > arr[n2])
        {
          int temp = arr[n2];
          arr[n2] = arr[n1];
          arr[n1] = temp;
        }
        n1++;
        n2++;
      }
    }
    
    for(int i=0; i<size; i++)
    {
      cout << arr[i] << "  ";
    }
    
    return 0;
}