#include <iostream>
using namespace std;

int check(int x, int y, int z){
    int a=x, b=y, c=z;
    
    if(y>x && y>z){
        a = y; 
        b = x; 
        c = z;
    }
    else if (z>x){
        a = z;
        b = x;
        c = y;
    }
    
    if(a*a == b*b + c*c)
        return 1;
    else
        return 0;
}

int main()
{
	int x, y, z;
	cin >> x >> y >> z;
	
	if(check(x,y,z))
	    cout << "Pythagorien triplet";
	else
	    cout << "Not pythagorien triplet";
	
	return 0;
}