#include <bits/stdc++.h>
using namespace std;

int addition(int a, int b){
    int l1, l2, i=1, sum=0;
    bool carr = 0;
    
    while(a>0 || b>0){
        l1 = a % 10;
        l2 = b % 10;
        
        if(l1==0 && l2==0 && carr){
            sum += 1*i;
            carr = 0;
        }
        else if((l1==0 && l2 ==1) || (l1==1 && l2 == 0)){
            if(carr){
                carr = 1;
            }
            else{
                sum += 1*i;
                carr = 0;
            }
        }
        else if(l1==1 && l2==1){
            if(carr)
            	sum += 1*i;
            carr = 1;
        }
        
        i *= 10;
        a /= 10;
        b /= 10;
    }
    
    if(carr)
        sum += 1*i;
    
    
    return sum;
}

int main(){
    int m;
    int n;
    cin >> m >> n;

    cout << addition(m, n) << endl;
    
    return 0;
}
