#include <iostream>
#include <string>
using namespace std;

int convert(string n){
    int d=0, x=1;
    int s = n.size();
    
    for(int i=s-1; i>=0; i--){
        if(n[i] >= '0' && n[i] <='9'){
            d += x*(n[i] - '0');
        }
        else if (n[i] >= 'A' && n[i] <= 'F'){
            d += x*(n[i] - 'A' + 10);
        }
        x *= 16;
    }
    
    return d;
}

int main(){
    string n;
    cin >> n;

    cout << convert(n) << endl;  
    return 0;
}