#include <iostream>
#include <cmath>
using namespace std;

int convert(int n){
    int l, d=0, i=0;
    while(n>0){
        l = n % 10;
        d = d + l * pow(2, i);
        n /= 10;
        i++;
    }
    return d;
}

int main(){
    int n;
    cin >> n;

    cout << convert(n) << endl;  
    return 0;
}