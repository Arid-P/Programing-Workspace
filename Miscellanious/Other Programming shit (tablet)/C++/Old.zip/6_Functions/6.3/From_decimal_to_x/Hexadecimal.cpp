#include <bits/stdc++.h>
using namespace std;

string convert(int n){
    int r;
    string ans = "";
    while(n>0){
        r = n % 16;
        if(r>=0 && r<=9){
            ans = ans + to_string(r);
        }
        else{
            char c = 'A' + (r - 10);
            ans.push_back(c);
        }
        n /= 16;
    }
    return ans;
}

int main(){
    int n;
    cin >> n;

    string ans = convert(n);

    for(int i=ans.size()-1; i>=0; i--)
        cout << ans[i];
    cout << endl;
            
    return 0;
}
