#include <bits/stdc++.h>
using namespace std;

int convert(int n, int ans[]){
    int i=0;
    while(n>0){
        ans[i] = n%2;
        n /= 2;
        i++;
    }
    return i;
}

int main(){
    int n, j=1;
    cin >> n;
    
    while(j<=n)
        j *= 2;
    
    j /= 2;
    
    int ans[j];
    j = convert(n, ans);
    
    for(int i=j-1; i>=0; i--)
        cout << ans[i];
    
    return 0;
}
