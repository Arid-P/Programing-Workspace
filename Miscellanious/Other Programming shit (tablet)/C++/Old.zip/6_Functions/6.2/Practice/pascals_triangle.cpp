#include <iostream>
using namespace std;

int fact(int n){
    int fac = 1;
    for(int i=2; i<=n; i++)
        fac *= i;
    
    return fac;
}

int nCr(int a, int b){
    int c;
    c = fact(a) / ((fact(b)*fact(a-b)));
    return c;
}

int main(){
    int n;
    cin >> n;

    for(int i=0; i<n; i++){
        for(int j=0; j<=i; j++)
            cout << nCr(i, j) << " ";
        cout << endl;
    }
    
    return 0;
}
