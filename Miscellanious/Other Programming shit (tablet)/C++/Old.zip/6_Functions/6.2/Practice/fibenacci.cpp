#include <iostream>
using namespace std;

void fibenacci(int n){
    int t3, t1=0, t2=1;
    for(int i=1; i<n; i++){
        cout << t1 << endl;
        t3 = t1 + t2;
        t1=t2;
        t2=t3;
    }
    cout << t1 << endl;

    return;
}

int main(){
    int n;
    cin >> n;

    fibenacci(n);
    
    return 0;
}
